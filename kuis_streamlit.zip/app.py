
import streamlit as st

st.set_page_config(page_title="Petualangan Belajar", layout="centered")
st.title("Petualangan Belajar - Kuis Seru!")
st.markdown("Halo! Aplikasi ini adalah kuis edukatif untuk anak-anak dengan level-level seru!")

# Simulasi tampilan karena frontend aslinya menggunakan HTML/JS/CSS terpisah
st.markdown("Silakan jalankan versi HTML/Flask untuk pengalaman penuh dengan gambar dan animasi.")
